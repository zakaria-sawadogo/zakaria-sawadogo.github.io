"use client";

import { useEffect } from "react";

const dictionary: Record<string, string> = {
  "About": "À propos",
  "Research": "Recherche",
  "Publications": "Publications",
  "Projects": "Projets",
  "Teaching": "Enseignement",
  "Lab": "Laboratoire",
  "Contact": "Contact",
  "Lecturer & Researcher": "Enseignant-Chercheur",
  "Artificial Intelligence • Cybersecurity • Data Science": "Intelligence Artificielle • Cybersécurité • Science des Données",
  "Cybersecurity • Artificial Intelligence • Data Science • Digital Development": "Cybersécurité • Intelligence Artificielle • Science des Données • Développement Numérique",
  "Lecturer and researcher building secure, intelligent, and inclusive digital systems for institutions, communities, and Africa's digital transformation.": "Enseignant-chercheur développant des systèmes numériques sécurisés, intelligents et inclusifs pour les institutions, les communautés et la transformation numérique de l’Afrique.",
  "Research interests": "Intérêts de recherche",
  "Secure Digital Systems": "Systèmes numériques sécurisés",
  "Research on malware detection, cyber threat intelligence, privacy, and trustworthy AI.": "Recherche sur la détection des malwares, la cyber threat intelligence, la confidentialité et l’IA digne de confiance.",
  "Policy & Digital Development": "Politiques publiques et développement numérique",
  "Applied work connecting digital rights, AI governance, inclusion, and institutional transformation.": "Travaux appliqués reliant droits numériques, gouvernance de l’IA, inclusion et transformation institutionnelle.",
  "Current work": "Travaux en cours",
  "View project": "Voir le projet",
  "Selected Recent Publications": "Publications récentes sélectionnées",
  "All publications": "Toutes les publications",
  "Current projects": "Projets en cours",
  "Service & recognition": "Services et distinctions",
  "Experience": "Expérience",
  "Education": "Formation",
  "Funding": "Financements",
  "Open focus": "Encadrement et collaborations",
  "Students interested in AI, cybersecurity, Android malware, privacy, and data systems are welcome to send a concise research statement.": "Les étudiants intéressés par l’IA, la cybersécurité, les malwares Android, la confidentialité et les systèmes de données peuvent envoyer une brève note de recherche.",
  "Lecturer and researcher in AI, cybersecurity, data science, and digital transformation.": "Enseignant-chercheur en IA, cybersécurité, science des données et transformation numérique.",
  "Join": "S'inscrire",
  "Newsletter": "Infolettre",
  "Navigation": "Navigation",
  "All rights reserved.": "Tous droits réservés.",
  "Research Areas": "Axes de recherche",
  "Students": "Étudiants",
  "Secure, intelligent systems for real institutions": "Des systèmes intelligents et sécurisés pour des institutions réelles",
  "The research program connects artificial intelligence, security, privacy, and data science with practical digital transformation needs.": "Le programme de recherche relie l’intelligence artificielle, la sécurité, la confidentialité et la science des données aux besoins concrets de transformation numérique.",
  "Recent publications and projects": "Publications et projets récents",
  "Biography, academic path, and responsibilities": "Biographie, parcours académique et responsabilités",
  "A concise view of the academic profile, research trajectory, teaching activity, and institutional engagement.": "Une présentation concise du profil académique, du parcours de recherche, des activités d’enseignement et de l’engagement institutionnel.",
  "Profile": "Profil",
  "Academic Biography": "Biographie académique",
  "Current appointment": "Fonction actuelle",
  "Read more": "Lire la suite",
  "Show less": "Voir moins",
  "AI, cybersecurity, privacy-preserving computing, and data-driven digital transformation.": "IA, cybersécurité, calcul préservant la confidentialité et transformation numérique guidée par les données.",
  "Computer science, artificial intelligence, cybersecurity, and software engineering.": "Informatique, intelligence artificielle, cybersécurité et génie logiciel.",
  "Digital governance, Internet development, cybersecurity initiatives, and collaborations.": "Gouvernance numérique, développement de l’Internet, initiatives en cybersécurité et collaborations.",
  "Service": "Engagement",
  "Academic Path": "Parcours académique",
  "Professional Experience": "Expérience professionnelle",
  "Affiliation": "Affiliation",
  "Core Expertise": "Expertises clés",
  "Academic program design and teaching coordination": "Conception de programmes académiques et coordination pédagogique",
  "Research supervision in AI and cybersecurity": "Encadrement de recherches en IA et cybersécurité",
  "Industry and public-sector digital transformation advisory": "Conseil en transformation numérique pour l’industrie et le secteur public",
  "Selected Policy & Advisory Contributions": "Contributions sélectionnées en politiques publiques et conseil",
  "Co-author, Digital Rights Manual for Beginners (DRIF 2025).": "Co-auteur, Digital Rights Manual for Beginners (DRIF 2025).",
  "Digital Rights Expert, African Internet Freedom Forum (2024).": "Expert en droits numériques, African Internet Freedom Forum (2024).",
  "Contributor to national initiatives on digital rights, cybersecurity awareness, and digital governance in Burkina Faso.": "Contributeur à des initiatives nationales sur les droits numériques, la sensibilisation à la cybersécurité et la gouvernance numérique au Burkina Faso.",
  "Contributed to AI research, policy, and digital development through Deep Learning Indaba and AI4D Africa.": "Contribution à la recherche en IA, aux politiques publiques et au développement numérique à travers Deep Learning Indaba et AI4D Africa.",
  "Facilitator of multi-stakeholder dialogues involving government, academia, civil society, and development partners.": "Facilitateur de dialogues multipartites impliquant gouvernement, milieu académique, société civile et partenaires au développement.",
  "PASET Regional Scholarship and Innovation Fund (RSIF) Scholar": "Boursier PASET Regional Scholarship and Innovation Fund (RSIF)",
  "Partnership for Skills in Applied Sciences, Engineering and Technology": "Partnership for Skills in Applied Sciences, Engineering and Technology",
  "Selected among outstanding African researchers for a highly competitive doctoral fellowship valued at approximately USD 100,000. Funded by the World Bank and supported by the African Union, the programme promotes advanced research, innovation, international collaboration, and scientific leadership across Africa.": "Sélectionné parmi des chercheurs africains d’excellence pour une bourse doctorale très compétitive d’une valeur d’environ 100 000 USD. Financé par la Banque mondiale et soutenu par l’Union africaine, le programme promeut la recherche avancée, l’innovation, la collaboration internationale et le leadership scientifique en Afrique.",
  "Research areas": "Axes de recherche",
  "Each research area connects technologies, projects, and publications so the academic record stays navigable.": "Chaque axe de recherche relie technologies, projets et publications afin de rendre le parcours scientifique facilement navigable.",
  "Scholar-style publication index": "Index des publications de type Scholar",
  "Search publications": "Rechercher des publications",
  "Applied research and institutional platforms": "Recherche appliquée et plateformes institutionnelles",
  "Courses, practical work, and downloadable material": "Cours, travaux pratiques et ressources téléchargeables",
  "AI, Cybersecurity & Data Science Laboratory": "Laboratoire IA, Cybersécurité et Science des Données",
  "Grants and sponsored research": "Subventions et recherche financée",
  "Current and former supervisees": "Étudiants actuels et anciens encadrés",
  "Conference talks and invited lectures": "Conférences et communications invitées",
  "Distinctions and recognitions": "Distinctions et reconnaissances",
  "Research life, seminars, and workshops": "Vie scientifique, séminaires et ateliers",
  "Resources and academic documents": "Ressources et documents académiques",
  "Collaborations, supervision, and speaking invitations": "Collaborations, encadrement et invitations",
  "Academic curriculum vitae": "Curriculum vitae académique",
  "Master Sécurité Informatique — full program": "Master Sécurité Informatique — programme complet",
  "11-course program: C programming, security auditing, cryptanalysis, IT governance and risk management, applied AI for security, cryptography, blockchain technology, security by design, application security, web services, and malware analysis and data security. Full lecture notes, slide decks, and lab assignments for every course, published as a dedicated site.": "Programme de 11 cours : programmation en C, audit de sécurité, cryptanalyse, gouvernance et gestion des risques SI, IA appliquée à la sécurité, cryptographie, technologie blockchain, sécurité dès la conception (security by design), sécurité des applications, services web, et analyse de malwares et sécurisation des données. Supports de cours complets, diaporamas et travaux pratiques pour chaque matière, publiés sur un site dédié.",
  "Dr. Zakaria Sawadogo is a Lecturer and Researcher at the École Polytechnique de Ouagadougou (EPO), Burkina Faso, specializing in Artificial Intelligence, Cybersecurity, Data Science, and Digital Transformation. His research focuses on developing intelligent and secure digital systems that address societal challenges through innovative AI-driven solutions.\n\nHe obtained his Ph.D. in Computer Science from Gaston Berger University, Senegal, where his doctoral research explored machine learning techniques for the continuous evaluation and detection of Android malware. His work has contributed to advancing behavior-based malware detection, explainable AI for cybersecurity, and privacy-preserving intelligent systems.\n\nDr. Sawadogo has authored several peer-reviewed scientific publications in international journals and conferences. His current research interests include Artificial Intelligence, Machine Learning, Deep Learning, Android Malware Analysis, Cyber Threat Intelligence, Privacy-Preserving Computing, Federated Learning, Homomorphic Encryption, and AI for Sustainable Development.\n\nBeyond research, he is actively involved in teaching undergraduate and graduate courses in computer science, artificial intelligence, cybersecurity, and software engineering. He has supervised numerous student projects and promotes practical, research-oriented education.\n\nHe has also contributed to several national and international initiatives related to digital governance, Internet development, and cybersecurity. His professional engagement includes leadership roles within the Internet Society Burkina Faso Chapter (ISOC Burkina Faso) and participation in regional and international research collaborations.\n\nHis long-term vision is to establish a Center of Excellence in Artificial Intelligence and Cybersecurity that fosters cutting-edge research, innovation, capacity building, and international collaboration to support Africa's digital transformation.": "Dr Zakaria Sawadogo est Enseignant-Chercheur à l’École Polytechnique de Ouagadougou (EPO), au Burkina Faso. Il est spécialisé en intelligence artificielle, cybersécurité, science des données et transformation numérique. Ses recherches portent sur le développement de systèmes numériques intelligents et sécurisés capables de répondre à des défis sociétaux grâce à des solutions innovantes fondées sur l’intelligence artificielle.\n\nIl a obtenu son doctorat en informatique à l’Université Gaston Berger du Sénégal, où ses travaux doctoraux ont exploré les techniques d’apprentissage automatique pour l’évaluation continue et la détection des logiciels malveillants Android. Ses recherches contribuent à l’avancement de la détection comportementale des malwares, de l’intelligence artificielle explicable appliquée à la cybersécurité et des systèmes intelligents respectueux de la vie privée.\n\nDr Sawadogo est auteur de plusieurs publications scientifiques évaluées par les pairs dans des revues et conférences internationales. Ses intérêts de recherche actuels incluent l’intelligence artificielle, l’apprentissage automatique, l’apprentissage profond, l’analyse des malwares Android, la cyber threat intelligence, le calcul préservant la confidentialité, l’apprentissage fédéré, le chiffrement homomorphe et l’IA pour le développement durable.\n\nAu-delà de la recherche, il intervient activement dans l’enseignement de cours de premier cycle et de cycle supérieur en informatique, intelligence artificielle, cybersécurité et génie logiciel. Il a encadré de nombreux projets étudiants et promeut une formation pratique, orientée recherche et innovation.\n\nIl a également contribué à plusieurs initiatives nationales et internationales liées à la gouvernance numérique, au développement de l’Internet et à la cybersécurité. Son engagement professionnel comprend des responsabilités au sein du chapitre Internet Society Burkina Faso (ISOC Burkina Faso) ainsi que des collaborations de recherche régionales et internationales.\n\nSa vision à long terme est de mettre en place un Centre d’Excellence en Intelligence Artificielle et Cybersécurité favorisant la recherche de pointe, l’innovation, le renforcement des capacités et la collaboration internationale au service de la transformation numérique de l’Afrique."
};

const reverseDictionary = Object.fromEntries(Object.entries(dictionary).map(([english, french]) => [french, english]));

function translateTextNode(node: Text, language: "en" | "fr") {
  const value = node.nodeValue;
  if (!value) return;
  const trimmed = value.trim();
  if (!trimmed) return;

  const replacement = language === "fr" ? dictionary[trimmed] : reverseDictionary[trimmed];
  if (!replacement) return;

  node.nodeValue = value.replace(trimmed, replacement);
}

function applyLanguage(language: "en" | "fr") {
  document.documentElement.lang = language;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent) return NodeFilter.FILTER_REJECT;
      if (["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "CODE", "PRE"].includes(parent.tagName)) {
        return NodeFilter.FILTER_REJECT;
      }
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  const nodes: Text[] = [];
  while (walker.nextNode()) nodes.push(walker.currentNode as Text);
  nodes.forEach((node) => translateTextNode(node, language));
}

export function LanguageRuntime() {
  useEffect(() => {
    const initial = (window.localStorage.getItem("site-language") === "fr" ? "fr" : "en") as "en" | "fr";
    applyLanguage(initial);

    const onLanguageChange = (event: Event) => {
      const language = (event as CustomEvent<"en" | "fr">).detail;
      applyLanguage(language);
    };

    window.addEventListener("site-language-change", onLanguageChange);
    const observer = new MutationObserver(() => {
      const language = (window.localStorage.getItem("site-language") === "fr" ? "fr" : "en") as "en" | "fr";
      applyLanguage(language);
    });
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      window.removeEventListener("site-language-change", onLanguageChange);
      observer.disconnect();
    };
  }, []);

  return null;
}
